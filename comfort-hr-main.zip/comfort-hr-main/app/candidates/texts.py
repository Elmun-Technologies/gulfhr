"""Nomzodlarni saralash bo'limi matnlari (o'zbek tilida)."""

from __future__ import annotations

WELCOME = (
    "Assalomu alaykum! 👋\n\n"
    "<b>Comfort</b> — Sotuvchi/Dastavka vakansiyasiga murojaat qilganingiz uchun rahmat.\n\n"
    "🧑🏻‍💼 Lavozim: Sotuvchi/Dastavka\n"
    "💵 Oylik: 10 000 000 – 15 000 000 so'm\n"
    "📌 Manzil: Toshkent, O'rikzor bozori atrofida\n\n"
    "Talablarga mos kelishini bilish uchun bir nechta savol beraman. "
    "Javoblaringiz to'g'ridan-to'g'ri HR bo'limiga yuboriladi."
)

ASK_FULL_NAME = "1️⃣ Ism va familiyangizni to'liq kiriting:"
ASK_GENDER = "2️⃣ Jinsingizni tanlang:"
ASK_AGE = "3️⃣ Necha yoshdasiz? (faqat raqamda, masalan: 22)"
ASK_AGE_INVALID = "Iltimos, yoshingizni faqat raqamda kiriting (masalan: 22)."
ASK_CITY = "4️⃣ Doimiy {city}da istiqomat qilasizmi? (Yotoqxona berilmaydi)"
ASK_PHONE = (
    "5️⃣ Telefon raqamingizni yuboring — pastdagi tugma orqali yoki qo'lda kiriting "
    "(masalan: +998901234567):"
)
ASK_PHONE_INVALID = "Telefon raqami noto'g'ri formatda. Masalan: +998901234567"
ASK_EXPERIENCE = (
    "6️⃣ Ish tajribangiz (staj) bormi? Qisqacha yozib bering:\n"
    "(Masalan: \"2 yil sotuvchi\", \"3 oy dastavka\", \"tajribam yo'q\")"
)
ASK_RESUME = (
    "7️⃣ Rezume yoki tajribangiz haqida ovozli xabar (golos) yuborishingiz mumkin.\n"
    "Shuningdek, fayl (PDF, DOC) ko'rinishida ham yuborishingiz mumkin.\n\n"
    "Agar yubormoqchi bo'lmasangiz, pastdagi tugmani bosing 👇"
)

BTN_YES = "✅ Ha"
BTN_NO = "❌ Yo'q"
BTN_MALE = "👨 Erkak"
BTN_FEMALE = "👩 Ayol"
BTN_SHARE_CONTACT = "📱 Raqamni yuborish"
BTN_SKIP_RESUME = "⏭ O'tkazib yuborish"

GENDER_LABELS = {"male": "Erkak", "female": "Ayol"}

RESULT_QUALIFIED = (
    "✅ Rahmat, {name}!\n\n"
    "Siz vakansiya talablariga javob berasiz. Tez orada HR mutaxassisi siz bilan "
    "bog'lanadi.\n\n"
    "Kuting va telefoningizni yoningizda tuting 📞"
)

RESULT_NOT_QUALIFIED = (
    "Rahmat, {name}, ariza uchun!\n\n"
    "Afsuski, hozircha quyidagi sabab(lar)ga ko'ra ushbu vakansiya talablariga "
    "to'liq mos kelmaysiz:\n{reasons}\n\n"
    "Boshqa mos vakansiyalar bo'lsa, albatta siz bilan bog'lanamiz. E'tiboringiz uchun rahmat!"
)

CANCELLED = "Ariza bekor qilindi. Qaytadan boshlash uchun /start ni bosing."
STATS_GROUP_ONLY = (
    "📊 Analitikani faqat HR guruhida ko'rish mumkin. Guruhda /stats deb yozing."
)
STATS_ERROR = (
    "Kechirasiz, analitika hisobotini tuzishda xato yuz berdi. "
    "Iltimos, keyinroq qayta urinib ko'ring."
)

GROUP_HEADER_QUALIFIED = "🟢 <b>YANGI NOMZOD — MOS KELADI</b>"
GROUP_HEADER_NOT_QUALIFIED = "🔴 <b>YANGI NOMZOD — MOS KELMAYDI</b>"
